<?php
namespace OpenCATS\Entity;

class CompanyRepositoryException extends \Exception {}