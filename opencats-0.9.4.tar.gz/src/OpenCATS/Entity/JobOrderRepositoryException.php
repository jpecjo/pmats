<?php
namespace \OpenCATS\Entity;
class JobOrderRepositoryException extends Exception {}